package com.capgemini.manytomany;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Events {
@Id
private String eventId;
private String eventName;
private LocalDate date;
@ManyToMany 
@JoinTable(name="event_delegate",joinColumns={@JoinColumn(name="events")},inverseJoinColumns= {@JoinColumn(name="delegates")})
private List<Delegates> delegate=new ArrayList<>();
public Events() {
	
}

public Events(String eventId, String eventName) {
	super();
	this.eventId = eventId;
	this.eventName = eventName;
}

public Events(String eventId, String eventName, LocalDate date) {
	super();
	this.eventId = eventId;
	this.eventName = eventName;
	this.date = date;
}

public LocalDate getDate() {
	return date;
}

public void setDate(LocalDate date) {
	this.date = date;
}

public String getEventId() {
	return eventId;
}
public void setEventId(String eventId) {
	this.eventId = eventId;
}
public String getEventName() {
	return eventName;
}
public void setEventName(String eventName) {
	this.eventName = eventName;
}
public List<Delegates> getDelegate() {
	return delegate;
}
public void setDelegate(List<Delegates> delegate) {
	this.delegate = delegate;
}
@Override
public String toString() {
	return "Events [eventId=" + eventId + ", eventName=" + eventName + "]";
}

}
