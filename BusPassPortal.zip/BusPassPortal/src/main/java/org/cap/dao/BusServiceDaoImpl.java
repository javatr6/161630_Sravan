package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.cap.model.RouteBean;

public class BusServiceDaoImpl implements IBusServiceDao {

	@Override
	public List<RouteBean> getAllRoutes() {
		
		List<RouteBean> routeBeans=new ArrayList<>();
	
		String sql="select * from route";
		
		try(PreparedStatement pst=getMySQLDBConnection().prepareStatement(sql)){
			
			ResultSet rs= pst.executeQuery();
			
			while(rs.next()) {
				RouteBean routeBean=new RouteBean();
				routeBean.setRouteid(rs.getInt("routeid"));
				routeBean.setRoutepath(rs.getString("routepath"));
				routeBean.setRoutename(rs.getString("routename"));
				routeBean.setBusno(rs.getString("busno"));
				routeBean.setDriverNo(rs.getString("driverno"));
				routeBean.setOccupiedseats(rs.getInt("occupiedseats"));
				routeBean.setTotalseats(rs.getInt("totalseats"));
				routeBean.setTotalKilotmeters(rs.getInt("totalkilometers"));
				
				routeBeans.add(routeBean);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return routeBeans;
	}
	
	private Connection getMySQLDBConnection() {
		Connection connection=null;
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/capdb", "root", "India123");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

}
